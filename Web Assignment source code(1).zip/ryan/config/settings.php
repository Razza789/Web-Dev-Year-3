<?php
define('BASEPATH', '/coursework/App');
define('USER_DATABASE', 'db/users.sqlite');
define('CHI_DATABASE', 'db/chi2023.sqlite');
define('SECRET', 'uJe8aBUQTGwHGa0sFzh47UeG7YoQhBxV');
?>